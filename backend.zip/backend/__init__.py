"""Backend package initialization."""

# Make core modules available at package level
from . import auth
from . import dexter_brain
from . import service
from . import main

__all__ = ['auth', 'dexter_brain', 'service', 'main']

